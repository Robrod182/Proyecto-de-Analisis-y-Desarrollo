<ul class="nav navbar-right top-nav">
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION["nomb_comp"]; ?> <b class="caret"></b></a>
        <ul class="dropdown-menu">
            <li>
                <a href="perfil.php"><i class="fa fa-fw fa-user"></i> Perfil</a>
            </li>
            <li class="divider"></li>
            <li>
                <a href="logout.php"><i class="fa fa-fw fa-power-off"></i> Cerrar sesion</a>
            </li>
        </ul>
    </li>
</ul>

