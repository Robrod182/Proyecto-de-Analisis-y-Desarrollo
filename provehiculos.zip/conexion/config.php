<?php
  $serv="localhost";
  $user="root";
  $pass="";
  $namedb="provehiculos";
?>